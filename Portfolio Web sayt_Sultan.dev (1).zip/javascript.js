
let ism='5';
console.log(Number(ism)+ 10);